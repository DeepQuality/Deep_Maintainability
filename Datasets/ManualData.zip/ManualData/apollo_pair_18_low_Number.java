package com.ctrip.framework.apollo.portal.entity.vo;

public class Number {
  private int num;

  public Number(int num){
    this.num = num;
  }

  public int getNum() {
    return num;
  }

  public void setNum(int num) {
    this.num = num;
  }
}
