package com.ctrip.framework.apollo.portal.entity.vo;

public class PermissionCondition {

  private boolean hasPermission;

  public boolean hasPermission() {
    return hasPermission;
  }

  public void setHasPermission(boolean hasPermission) {
    this.hasPermission = hasPermission;
  }
}
